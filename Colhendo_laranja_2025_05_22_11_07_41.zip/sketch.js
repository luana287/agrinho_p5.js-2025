function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let oranges = [];

function setup() {

  createCanvas(600, 400);

  // Criar laranjas em posições aleatórias na copa da árvore

  for (let i = 0; i < 10; i++) {

    oranges.push({

      x: random(200, 400),

      y: random(100, 200),

      size: 25,

      picked: false

    });

  }

}

function draw() {

  background(135, 206, 235); // céu

  drawTree();

  // Desenhar laranjas

  for (let o of oranges) {

    if (!o.picked) {

      fill(255, 165, 0);

      noStroke();

      circle(o.x, o.y, o.size);

    }

  }

}

function drawTree() {

  // Tronco

  fill(139, 69, 19);

  rect(280, 200, 40, 150);

  // Copa

  fill(34, 139, 34);

  ellipse(300, 150, 200, 150);

}

function mousePressed() {

  for (let o of oranges) {

    let d = dist(mouseX, mouseY, o.x, o.y);

    if (d < o.size / 2 && !o.picked) {

      o.picked = true;

    }

  }

}